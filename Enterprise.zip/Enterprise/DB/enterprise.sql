-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2020 at 05:08 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enterprise`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `userID` varchar(5) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `adminGender` varchar(6) NOT NULL,
  `adminAge` int(2) NOT NULL,
  `adminEmail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`userID`, `adminName`, `adminGender`, `adminAge`, `adminEmail`) VALUES
('A001', 'Hiro', 'Male', 22, 'hiroshenrao3@gmail.com'),
('A002', 'Olivia', 'Female', 35, 'olivia@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `allocate`
--

CREATE TABLE `allocate` (
  `AllocateID` int(11) NOT NULL,
  `StudentName` varchar(255) NOT NULL,
  `StudentEmail` varchar(100) NOT NULL,
  `TutorName` varchar(255) NOT NULL,
  `TutorEmail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `allocate`
--

INSERT INTO `allocate` (`AllocateID`, `StudentName`, `StudentEmail`, `TutorName`, `TutorEmail`) VALUES
(1, 'Teoh', 'stark9812@gmail.com', 'Kean', 'keanheeooi@gmail.com'),
(2, 'David', 'david@gmail.com', 'Daniel', 'daniel@gmail.com'),
(3, 'Vernon', 'vernon@gmail.com', 'Kean', 'keanheeooi@gmail.com'),
(4, 'Joshua', 'joshua@gmail.com', 'Kean', 'keanheeooi@gmail.com'),
(5, 'John', 'john@gmail.com', 'Joseph', 'joseph@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `blogid` int(11) NOT NULL,
  `blogtitle` longtext NOT NULL,
  `blogcontent` longblob NOT NULL,
  `userid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blogid`, `blogtitle`, `blogcontent`, `userid`) VALUES
(1, 'Experts', 0x616161, 'S001'),
(3, 'Experts', 0x616161616161616161616161616161, 'S002'),
(10, 'Experts', 0x61, 'T001'),
(14, 'ssssssssssssssssssssssss', 0x7373737373, 'T001'),
(17, 'sdee', 0x6464646464, 'S001');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `Id` int(11) NOT NULL,
  `send` varchar(150) NOT NULL,
  `receive` varchar(150) NOT NULL,
  `contents` text NOT NULL,
  `times` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`Id`, `send`, `receive`, `contents`, `times`) VALUES
(1, '12', 'Mark', 'hi', ''),
(2, '12', 'Mark', 'hi', ''),
(3, '12', 'Mark', 'hi', ''),
(4, '12', 'hiro@gmail.com', 'gg', ''),
(5, '', 'hiro@gmail.com', 'ok', ''),
(6, '', 'hiro@gmail.com', 'ok', ''),
(7, '', 'hiro@gmail.com', 'ok', ''),
(8, '', 'hiro@gmail.com', 'hi', ''),
(9, '', 'hiro@gmail.com', 'hi', ''),
(10, '', 'hiro@gmail.com', 'bye', ''),
(11, 'Mark', 'hiro@gmail.com', 'hi', ''),
(12, '11', 'kumarenthevar23@gmail.com', 'bye', ''),
(13, '11', 'kumarenthevar23@gmail.com', 'hi', ''),
(14, '11', 'kumarenthevar23@gmail.com', 'gg', '2020-04-16 16:20:14'),
(15, '11', 'kumarenthevar23@gmail.com', '123', '2020-04-16 04:21:50'),
(16, '11', 'kumarenthevar23@gmail.com', 'ok', '2020-04-16 16:22:36'),
(17, '11', 'kumarenthevar23@gmail.com', 'need', '2020-04-16 22:26:08'),
(18, 'Mark', 'hiro@gmail.com', 'Hi', ''),
(19, 'Mark', 'hiro@gmail.com', 'byr', 'Date is 22-04-2020Time is 16:37:22'),
(20, 'Mark', 'hiro@gmail.com', 'ggwp', 'Date is 22-04-2020Time is 16:37:42'),
(21, 'Mark', 'hiro@gmail.com', 'hi and bye', 'Date is 22-04-2020Time is 18:09:18'),
(22, 'Teoh', 'kumarenthevar23@gmail.com', 'bb', '2020-04-22 18:11:19'),
(23, 'Teoh', 'kumarenthevar23@gmail.com', 'Hi and Bye\r\n', '2020-04-22 18:13:23'),
(24, 'Teoh', 'kumarenthevar23@gmail.com', 'gg', '2020-04-22 18:16:25'),
(25, 'Teoh', 'kumarenthevar23@gmail.com', 'hi', '2020-04-22 18:21:19'),
(26, 'Teoh', 'kumarenthevar23@gmail.com', 'gg', '2020-04-22 18:23:19'),
(27, 'Teoh', 'kumarenthevar23@gmail.com', 'Why no coming', '2020-04-22 18:37:38'),
(28, 'Teoh', 'kumarenthevar23@gmail.com', 'y', '2020-04-22 18:51:39'),
(29, 'kumarenthevar23@gmail.com', 'Teoh', 'hi', '2020-04-22 18:56:52'),
(30, 'Mark', 'hiro@gmail.com', 'hi', 'Date is 22-04-2020Time is 19:00:27'),
(31, 'Mark', 'hiro@gmail.com', 'Chat', 'Date is 22-04-2020Time is 19:49:47'),
(32, 'Teoh', 'Kean', 'fsddfsdfs', '2020-04-24 16:03:31'),
(33, 'Teoh', 'Kean', 'Hey whats up', '2020-04-24 16:03:51'),
(34, 'Kean', 'Teoh', 'Yeah I\'m fine bro', 'Date is 24-04-2020Time is 16:04:38'),
(35, 'Teoh', 'Kean', 'ssssssssssssss', '2020-04-24 23:35:15'),
(36, 'Teoh', 'Kean', 'Leo what you doing', '2020-04-24 23:35:30'),
(37, 'Kean', 'Teoh', 'Can loh', 'Date is 25-04-2020Time is 00:14:39'),
(38, 'Kean', 'Teoh', 'asasa', 'Date is 25-04-2020Time is 00:35:34');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(9) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `filename`, `comment`, `created`) VALUES
(37, '37-happydoctor.jpg', 'adsdsds', '2020-04-25 09:32:47'),
(38, '38-seq02.gif', 'Sequence Diagram', '2020-04-25 09:33:58'),
(36, '36-45-452124_drawing-stickman-happy-child-stick-figure-png-transparent.png', 'aa', '2020-04-25 09:32:12'),
(33, '1-unnamed.png', 'aa', '2020-04-24 18:28:33'),
(34, '34-unnamed.png', 'aaa', '2020-04-24 18:30:43'),
(35, '35-close-portrait-smiling-handsome-man-260nw-1011569245.webp', 'aaa', '2020-04-24 19:21:40');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `ID` varchar(11) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`ID`, `Username`, `Email`, `Category`, `Password`) VALUES
('A001', 'Hiro', 'hiroshenrao3@gmail.com', 'Admin', 'hiro12345'),
('A002', 'Olivia', 'olivia@gmail.com', 'Admin', 'olivia12345'),
('S001', 'Teoh', 'stark9812@gmail.com', 'Student', 'teoh12345'),
('S002', 'David', 'david@gmail.com', 'Student', 'david12345'),
('S003', 'John', 'john@gmail.com', 'Student', 'john12345'),
('S004', 'Nicholas', 'nicholas@gmail.com', 'Student', 'nicholas12345'),
('S005', 'Kevin', 'kevin@gmail.com', 'Student', 'kevin12345'),
('S006', 'Justin', 'justin@gmail.com', 'Student', 'justin12345'),
('S007', 'Austin', 'austin@gmail.com', 'Student', 'austin12345'),
('S008', 'Jason', 'jason@gmail.com', 'Student', 'jason12345'),
('S009', 'Luis', 'luis@gmail.com', 'Student', 'luis12345'),
('S010', 'Bentley', 'bentley@gmail.com', 'Student', 'bentley12345'),
('S011', 'Sean', 'sean@gmail.com', 'Student', 'sean12345'),
('S012', 'Richard', 'richard@gmail.com', 'Student', 'richard12345'),
('S013', 'Robert', 'robert@gmail.com', 'Student', 'robert12345'),
('S014', 'Noah', 'noah@gmail.com', 'Student', 'noah12345'),
('S015', 'Gary', 'gary@gmail.com', 'Student', 'gary12345'),
('S016', 'Jose', 'jose@gmail.com', 'Student', 'jose12345'),
('S017', 'Ian', 'ian@gmail.com', 'Student', 'ian12345'),
('S018', 'Adam', 'adam@gmail.com', 'Student', 'adam12345'),
('S019', 'Stephen', 'stephen@gmail.com', 'Student', 'stephen12345'),
('S020', 'Ralph', 'ralph@gmail.com', 'Student', 'ralph12345'),
('S021', 'Patrick', 'patrick@gmail.com', 'Student', 'patrick12345'),
('S022', 'Tristin', 'tristin@gmail.com', 'Student', 'tristin12345'),
('S023', 'Jessie', 'jessie@gmail.com', 'Student', 'jessie12345'),
('S024', 'Vernon', 'vernon@gmail.com', 'Student', 'vernon12345'),
('S025', 'Joshua', 'joshua@gmail.com', 'Student', 'joshua12345'),
('T001', 'Kean', 'keanheeooi@gmail.com', 'Tutor', 'kean12345'),
('T002', 'Daniel', 'daniel@gmail.com', 'Tutor', 'daniel12345'),
('T003', 'Joseph', 'joseph@gmail.com', 'Tutor', 'joseph12345'),
('T004', 'Riley', 'riley@gmail.com', 'Tutor', 'riley12345'),
('T005', 'Colin', 'colin@gmail.com', 'Tutor', 'colin12345');

-- --------------------------------------------------------

--
-- Table structure for table `meeting`
--

CREATE TABLE `meeting` (
  `MeetingID` int(11) NOT NULL,
  `TutorName` varchar(255) NOT NULL,
  `StudentName` varchar(255) NOT NULL,
  `MeetingSubject` varchar(255) NOT NULL,
  `MeetingDetail` varchar(255) NOT NULL,
  `Date` varchar(100) NOT NULL,
  `Time` varchar(100) NOT NULL,
  `userid` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `meeting`
--

INSERT INTO `meeting` (`MeetingID`, `TutorName`, `StudentName`, `MeetingSubject`, `MeetingDetail`, `Date`, `Time`, `userid`) VALUES
(2, 'kumarenthevar23@gmail.com', 'stark9812@gmail.com', 'Historyx', 'Question', '22/04/2020', '11:22', 'S001'),
(3, 'kumarenthevar23@gmail.com', 'stark9812@gmail.com', 'Science', 'Question', '01/05/2020', '01:45', 'S001'),
(4, 'stark9812@gmail.com', 'mark@gmail.com', 'History', 'Question', '30/04/2020', '11:11', 'T001'),
(5, 'stark9812@gmail.com', 'teoh12345@gmail.com', 'History', 'Quetions', '25/04/2020', '12:11', 'T001'),
(6, 'stark9812@gmail.com', 'mark@gmail.com', 'History', 'Questions', '14/05/2020', '11:30', 'T001');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `userID` varchar(5) NOT NULL,
  `studentName` varchar(255) NOT NULL,
  `studentGender` varchar(6) NOT NULL,
  `studentAge` int(2) NOT NULL,
  `studentEmail` varchar(255) NOT NULL,
  `PersonalTutorName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`userID`, `studentName`, `studentGender`, `studentAge`, `studentEmail`, `PersonalTutorName`) VALUES
('S001', 'Teoh', 'Male', 22, 'stark9812@gmail.com', 'Kean'),
('S002', 'David', 'Male', 18, 'david@gmail.com', 'Daniel'),
('S003', 'John', 'Male', 18, 'john@gmail.com', 'Joseph'),
('S004', 'Nicholas', 'Male', 18, 'nicholas@gmail.com', ''),
('S005', 'Kevin', 'Male', 18, 'kevin@gmail.com', ''),
('S006', 'Justin', 'Male', 18, 'justin@gmail.com', ''),
('S007', 'Austin', 'Male', 18, 'austin@gmail.com', ''),
('S008', 'Jason', 'Male', 18, 'jason@gmail.com', ''),
('S009', 'Luis', 'Male', 18, 'luis@gmail.com', ''),
('S010', 'Bentley', 'Male', 18, 'bentley@gmail.com', ''),
('S011', 'Sean', 'Male', 18, 'sean@gmail.com', ''),
('S012', 'Richard', 'Male', 18, 'richard@gmail.com', ''),
('S013', 'Robert', 'Male', 18, 'robert@gmail.com', ''),
('S014', 'Noah', 'Female', 18, 'noah@gmail.com', ''),
('S015', 'Gary', 'Male', 18, 'gary@gmail.com', ''),
('S016', 'Jose', 'Male', 18, 'jose@gmail.com', ''),
('S017', 'Ian', 'Male', 18, 'ian@gmail.com', ''),
('S018', 'Adam', 'Male', 18, 'adam@gmail.com', ''),
('S019', 'Stephen', 'Male', 18, 'stephen@gmail.com', ''),
('S020', 'Ralph', 'Male', 18, 'ralph@gmail.com', ''),
('S021', 'Patrick', 'Male', 18, 'patrick@gmail.com', ''),
('S022', 'Tristin', 'Female', 18, 'tristin@gmail.com', ''),
('S023', 'Jessie', 'Female', 18, 'jessie@gmail.com', ''),
('S024', 'Vernon', 'Male', 18, 'vernon@gmail.com', 'Kean'),
('S025', 'Joshua', 'Male', 18, 'joshua@gmail.com', 'Kean');

-- --------------------------------------------------------

--
-- Table structure for table `tutor`
--

CREATE TABLE `tutor` (
  `userID` varchar(5) NOT NULL,
  `tutorName` varchar(255) NOT NULL,
  `tutorGender` varchar(6) NOT NULL,
  `tutorAge` int(2) NOT NULL,
  `tutorEmail` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tutor`
--

INSERT INTO `tutor` (`userID`, `tutorName`, `tutorGender`, `tutorAge`, `tutorEmail`) VALUES
('T001', 'Kean', 'Male', 22, 'keanheeooi@gmail.com'),
('T002', 'Daniel', 'Male', 40, 'daniel@gmail.com'),
('T003', 'Joseph', 'Male', 35, 'joseph@gmail.com'),
('T004', 'Riley', 'Female', 28, 'riley@gmail.com'),
('T005', 'Colin', 'Female', 32, 'colin@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `allocate`
--
ALTER TABLE `allocate`
  ADD PRIMARY KEY (`AllocateID`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`blogid`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `meeting`
--
ALTER TABLE `meeting`
  ADD PRIMARY KEY (`MeetingID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `tutor`
--
ALTER TABLE `tutor`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allocate`
--
ALTER TABLE `allocate`
  MODIFY `AllocateID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `blogid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `meeting`
--
ALTER TABLE `meeting`
  MODIFY `MeetingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
