<?php include('serverlogin.php');

//if user is not logged in, they cannot access this Page
if (empty($_SESSION['Email'])){
  header('location: staff.php');
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Home Page</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="header">
      <h2>Home Page-Student</h2>
    </div>

    <div class="content">
      <?php if (isset($_SESSION['success'])): ?>
        <div class="error success">
          <h3>
            <?php
             echo $_SESSION['success'];
             unset($_SESSION['success']);
             ?>
           </h3>
         </div>
      <?php endif ?>
      <?php if (isset($_SESSION["Email"])): ?>
        <p>Welcome <strong><?php echo $_SESSION['Email']; ?></strong></p>
        <p><a href="memberinsert.php?memberinsert='1'" style="color: red;">memberinsert</a></p>
        <p><a href="home.php?Logout='1'" style="color: red;">Logout</a></p>
      <?php endif ?>
    </div>
</body>
</html>
