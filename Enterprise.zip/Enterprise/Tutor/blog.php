<?php
$connection = mysqli_connect('localhost', 'root', '', 'enterprise');
session_start();
if(empty($_SESSION['Email'])) {
  header('location:/Enterprise/UserLogin.php');
}
elseif ($_SESSION['type']!=='Tutor') {
  echo "<script>window.open('/Enterprise/UserLogin.php', '_self')</script>";
}


$blogid=0;
$title = "";
$content = "";
$userid = "";
$tutorname="";
$edit = false;
$User = $_SESSION['uniqueuser'];

//Insert Blog Data
if (isset($_POST['Save_Blog'])) {
		//Security data
	$title = mysqli_real_escape_string($connection, $_POST['title']);
	$content = mysqli_real_escape_string($connection, $_POST['content']);
  $userid = "";
  $sql = "INSERT INTO `blog`(`blogid`, `blogtitle`, `blogcontent`, `userid`)
  VALUES (NULL, '$title', '$content','$User')";
  mysqli_query($connection, $sql);
	header('location:blog.php');
}

//Delete Blog
if (isset($_GET['Delete_Blog'])) {
	$blogid = $_GET['Delete_Blog'];
	mysqli_query($connection, "DELETE FROM blog WHERE blogid=$blogid");
	header('location:blog.php');
}

//Call out the data from the database once user choose the specific data from table
if (isset($_GET['Edit_Blog'])) {
		$blogid = $_GET['Edit_Blog'];
		$edit = true;
		$blogrecords = mysqli_query($connection, "SELECT * FROM blog WHERE blogid=$blogid");
		$blogrecs= mysqli_fetch_array($blogrecords);
		$title = $blogrecs['blogtitle'];
		$content = $blogrecs['blogcontent'];
}

if (isset($_POST['Update_Blog'])) {

//Variable to declare from the input name
$blogid= $_POST['blogidtable'];
$title = $_POST['title'];
$content = $_POST['content'];
mysqli_query($connection, "UPDATE blog SET blogtitle='$title',blogcontent='$content' WHERE blogid=$blogid");
header('location:blog.php');
}
 ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Tutor-Blog</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
  <?php
  $User = 	$_SESSION['uniqueuser'];
  $users = "SELECT * FROM login WHERE ID = '$User'";
  $results = mysqli_query($connection, $users);
  while($rows = mysqli_fetch_assoc($results)){;
  ?>
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <!-- Brand -->
    <a class="navbar-brand" href="Tutor.php"><?php echo $rows['Username']; ?></a>

    <!-- Links -->
    <ul class="navbar-nav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="TutorProfile.php">Tutor Profile</a>
        </li>
       <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="Upload.php">Upload File</a>
        </li>

        <ul class="navbar-nav">
         <li class="nav-item">
           <a class="nav-link" href="blog.php">My Blog</a>
         </li>
        </ul>

        <ul class="navbar-nav">
         <li class="nav-item">
           <a class="nav-link" href="meeting.php">Make Appointment</a>
         </li>

         <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="ViewStudent.php">View Student</a>
          </li>
          <ul class="navbar-nav">
           <li class="nav-item">
             <a class="nav-link" href="TutorChat.php">Chat</a>
           </li>
        <ul class="navbar-nav">
         <li class="nav-item">
           <a class="nav-link" href="/Enterprise/UserLogin.php?Logout='1'">LOGOUT</a>
         </li>
  </nav>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;

}
</style>
</head>
<body>

<br><h3>My Blog</h3>

<div class="container">
  <form  action="blog.php" method="POST">
		<input type="hidden" name="blogidtable" value="<?php echo $blogid; ?>">
    <input type="hidden" name="userid" value="<?php echo $rows['ID']; ?>">
  <label for="title"></label>
  	<input id="subject" type="text" name="title" placeholder="Write the topic" value="<?php echo $title; ?>" required>

    <label for="subject"></label>
    <textarea id="subject" name="content" placeholder="Write something content.." style="height:200px"  required><?php echo $content; ?></textarea>

		<?php if ($edit == false):?>
        <button type="submit" name="Save_Blog" class="btn btn-warning" style="width:80px;">Post</button>
    <?php else: ?>
        <button type="submit" name="Update_Blog" class="btn btn-success" style="width:200px;">Update Changes</button>
    <?php endif ?>
  </form>

	<br>
	<br>
	<br>
			<table class="table table-striped table-dark">
      <thead>
        <tr>
      	<th>Topic</th>
        <th>Content</th>
        <th colspan="2"><center>Action</center></th>
        </tr>
          </thead>
              <tbody>
                  <?php
                  $User = 	$_SESSION['uniqueuser'];
                  $users = "SELECT * FROM blog WHERE userid ='$User'";
                  $results = mysqli_query($connection, $users);
                  while($rows = mysqli_fetch_assoc($results)){;
                  ?>

                  <tr>
                    <td class="bg-warning"><?php echo $rows['blogtitle']; ?></td>
                    <td class="bg-info"><?php echo $rows['blogcontent']; ?></td>
                    <td class="text-right">
                        <a href="blog.php?Edit_Blog=<?php echo $rows['blogid']; ?>" class="btn btn-primary" style="width:80px;" >Edit</a>
                    </td>
                    <td>
                        <a href="blog.php?Delete_Blog=<?php echo $rows['blogid']; ?>" class="btn btn-danger" style="width:80px;">Delete</a>
                    </td>
                    </tr>
                    <?php } ?>
                </tbody>
								</table>
								</div>
<?php } ?>
</body>
</html>
