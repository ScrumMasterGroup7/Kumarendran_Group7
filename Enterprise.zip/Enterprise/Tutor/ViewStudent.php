<?php
$connection = mysqli_connect('localhost', 'root', '', 'enterprise');
session_start();
if(empty($_SESSION['Email'])) {
  header('location:/Enterprise/UserLogin.php');
}
elseif ($_SESSION['type']!=='Tutor') {
  echo "<script>window.open('/Enterprise/UserLogin.php', '_self')</script>";
}


$User = 	$_SESSION['uniqueuser'];
$sql ="SELECT StudentName, count(*) as number FROM meeting WHERE userid='$User'";
$resultmeeting = mysqli_query($connection,$sql);


 ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Tutor-View Student</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

  <script type="text/javascript">
  google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.setOnLoadCallback(drawAnnotations);

      function drawAnnotations() {
        var data = google.visualization.arrayToDataTable([
          ['StudentName', 'Number'],
          <?php

          while ($rows = mysqli_fetch_array($resultmeeting)) {
            echo "['".$rows["StudentName"]."',".$rows["number"]."],";
          }

          ?>
        ]);

        var options = {
        title: 'Meeting',
        hAxis: {
          title: 'Total Of Student Meeting',
          format: 'h:mm a',

        }
      };

      var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
  </script>

</head>
<body>
  <?php
  $User = 	$_SESSION['uniqueuser'];
  $users = "SELECT * FROM login WHERE ID = '$User'";
  $results = mysqli_query($connection, $users);
  while($rows = mysqli_fetch_assoc($results)){;
  ?>
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <!-- Brand -->
    <a class="navbar-brand" href="#"><?php echo $rows['Username']; ?></a>

    <!-- Links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="TutorProfile.php">Tutor Profile</a>
      </li>
     <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="Upload.php">Upload File</a>
      </li>

      <ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="blog.php">My Blog</a>
       </li>
      </ul>

      <ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="meeting.php">Make Appointment</a>
       </li>

       <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="ViewStudent.php">View Student</a>
        </li>
        <ul class="navbar-nav">
         <li class="nav-item">
           <a class="nav-link" href="TutorChat.php">Chat</a>
         </li>
      <ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="/Enterprise/UserLogin.php?Logout='1'">LOGOUT</a>
       </li>
  </nav>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;

}
</style>
</head>
<body>

<h3>View Student Appointment</h3>
        <table class="table">
        <thead class="thead-dark">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Student Name</th>
            <th scope="col">MeetingDetail</th>
          <th scope="col">Date</th>
          <th scope="col">Time</th>
          </tr>
        </thead>
        <tbody>
        <?php

        $sql= "SELECT * FROM meeting WHERE userid='$User'";
        $result = mysqli_query($connection,$sql);

        if ($result-> num_rows > 0) {
        while ($row = $result-> fetch_assoc()) {
          echo "<tr><td>". $row["userid"] ."</td><td>". $row["StudentName"]. "</td><td>". $row["MeetingDetail"]. "</td><td>". $row["Date"]. "</td><td>". $row["Time"]. "</td></tr>";
        }
        echo "</table>";
        }
        else {
        echo "0 result";
        }

        $connection-> close();
        ?>
        </table>

        <br>
        <table class="columns">
          <tr>
            <td><div id="chart_div"style="border: 2px solid #00FA9A" style="width:900px; height:550px;"></div></td>
          </tr>
        </table>
<?php } ?>
</body>
</html>
