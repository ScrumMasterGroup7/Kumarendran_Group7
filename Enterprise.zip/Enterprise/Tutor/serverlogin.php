<?php
  session_start();
    $Email = "";
    $Category = "";
    // connect to the database
    $sqlconnection = mysqli_connect('localhost', 'root', '', 'enterprisestaff');

// Check connection
if ($sqlconnection->connect_error) {
    die("Connection failed: " . $sqlconnection->connect_error);
}
echo "Connected successfully";

      //log user in
      if (isset($_POST['Login'])) {
        $Email =($_POST['Email']);
        $Password = ($_POST['Password']);
        $Category = ($_POST['Category']);
        $sql = "SELECT * FROM login WHERE Email='$Email' AND Password='$Password'";
        $check = mysqli_query($sqlconnection, $sql);
        if (mysqli_num_rows($check) == 1){
          $_SESSION['Email'] = $Email;
          $_SESSION['success'] = "You are now Log In!";
          switch ($Category){
            case 'Staff':
              header('location: Staff.php');
            break;
            case 'Tutor':
              header('location: Tutor.php');
            break;
            case 'Student':
              header('location: Student.php');
            break;
          }
        }

        }



    //Logout
    if (isset($_GET['Logout'])){
      session_destroy();
      unset($_SESSION['Email']);
      header('location: staff.php');
    }
 ?>
