<?php
$conn = mysqli_connect('localhost', 'root', '', 'enterprise');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();
if(empty($_SESSION['Email'])) {
  header('location:/Enterprise/UserLogin.php');
}
elseif ($_SESSION['type']!=='Tutor') {
  echo "<script>window.open('/Enterprise/UserLogin.php', '_self')</script>";
}



$userid=$_REQUEST['userid'];
$sql ="SELECT MeetingID, count(*) as number FROM meeting WHERE userid='$userid'";
$resultmeeting = mysqli_query($conn,$sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Tutor-Blog</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script type="text/javascript">
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {

      var data = google.visualization.arrayToDataTable([
        ['userid', 'Number'],
        <?php

        while ($rows = mysqli_fetch_array($resultblog)) {
          echo "['".$rows["MeetingID"]."',".$rows["number"]."],";
        }

        ?>
      ]);

      var options = {title:'Total Blog',
      width: 600,
      height: 400};

      var chart = new google.visualization.PieChart(document.getElementById('piechart_blog'));

      chart.draw(data, options);
    }
</script>
</head>
<body>
  <?php
  $User = $_SESSION['uniqueuser'];
  $users = "SELECT * FROM login WHERE ID = '$User'";
  $results = mysqli_query($conn, $users);
  while($rows = mysqli_fetch_assoc($results)){;
  ?>
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <!-- Brand -->
    <a class="navbar-brand" href="Tutor.php">MarkTeh</a>

    <!-- Links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="TutorProfile.php">Tutor Profile</a>
      </li>
     <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="Upload.php">Upload File</a>
      </li>
  <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="CommentBox.php">Comments</a>
      </li>
     <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="ViewStudent.php">ViewStudent</a>
      </li>

      <ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="meeting.php">Make Appointment</a>
       </li>

       <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="TutorChat.php">Chat</a>
        </li>

      <ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="/Enterprise/UserLogin.php?Logout='1'">LOGOUT</a>
       </li>
  </nav>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;

}
</style>
</head>
<body>

  <table class="columns">
    <tr>
      <td><div id="piechart_blog"style="border: 2px solid #00FA9A" style="width:900px; height:550px;"></div></td>
    </tr>
  </table>
<?php } ?>
</body>
</html>
