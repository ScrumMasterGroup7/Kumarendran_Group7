<?php
session_start();
include_once 'uploads.php';
$con = mysqli_connect('localhost', 'root', '', 'enterprise');
$User = $_SESSION["uniqueuser"];
// fetch files
$sql = "select * from files";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload View & Download file in PHP and MySQL | Demo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

</head>
<body>
  <?php
  $User = 	$_SESSION['uniqueuser'];
  $users = "SELECT * FROM login WHERE ID = '$User'";
  $results = mysqli_query($con, $users);
  while($rows = mysqli_fetch_assoc($results)){;
  ?>
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <!-- Brand -->
    <a class="navbar-brand" href="Tutor.php"><?php echo $rows['Username']; ?></a>

    <!-- Links -->
    <ul class="navbar-nav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="TutorProfile.php">Tutor Profile</a>
        </li>
       <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="Upload.php">Upload File</a>
        </li>

        <ul class="navbar-nav">
         <li class="nav-item">
           <a class="nav-link" href="blog.php">My Blog</a>
         </li>
        </ul>

        <ul class="navbar-nav">
         <li class="nav-item">
           <a class="nav-link" href="meeting.php">Make Appointment</a>
         </li>

         <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="ViewStudent.php">View Student</a>
          </li>
          <ul class="navbar-nav">
           <li class="nav-item">
             <a class="nav-link" href="TutorChat.php">Chat</a>
           </li>
        <ul class="navbar-nav">
         <li class="nav-item">
           <a class="nav-link" href="/Enterprise/UserLogin.php?Logout='1'">LOGOUT</a>
         </li>
  </nav>
<br/>
<div class="container">
    <div class="row">
        <div class="col-xs-8 col-xs-offset-2 well">
        <form action="uploads.php" method="post" enctype="multipart/form-data">
            <legend>Select File to Upload:</legend>
            <div class="form-group">
                <input type="file" name="file1" />
            </div>
			<div class="form-group">
                <input type="text" name="comment" />
            </div>
            <div class="form-group">
                <input type="submit" name="submit" value="Upload" class="btn btn-info"/>
            </div>
            <?php if(isset($_GET['st'])) { ?>
                <div class="alert alert-danger text-center">
                <?php if ($_GET['st'] == 'success') {
                        echo "File Uploaded Successfully!";
                    }
                    else
                    {
                        echo 'Invalid File Extension!';
                    } ?>
                </div>
            <?php } ?>
        </form>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-8 col-xs-offset-2">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>File Name</th>
						<th>Comment</th>
                        <th>View</th>
                        <th>Download</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $i = 1;
                while($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $row['filename']; ?></td>
					<td><?php echo $row['comment']; ?></td>
                    <td><a href="/Enterprise/Upload/<?php echo $row['filename']; ?>" target="_blank">View</a></td>
                    <td><a href="/Enterprise/Upload/<?php echo $row['filename']; ?>" download>Download</td>
                </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php } ?>
</body>
</html>
