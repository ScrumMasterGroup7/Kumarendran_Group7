<?php


$connection = mysqli_connect('localhost', 'root', '', 'enterprise');
session_start();
if(empty($_SESSION['Email'])) {
  header('location:/Enterprise/UserLogin.php');
}
elseif ($_SESSION['type']!=='Tutor') {
  echo "<script>window.open('/Enterprise/UserLogin.php', '_self')</script>";
}

 ?>


 <?php
 require './vendor/autoload.php';
 $MeetingID=0;
 $TN = "";
 $SN = "";
 $MS="";
 $MD="";
 $Date="";
 $Time="";

 $edit = false;
 $User = 	$_SESSION['uniqueuser'];
 //Insert Meeting Data
 if (isset($_POST['Book_Meeting'])) {

     $TN = mysqli_real_escape_string($connection, $_POST['Tutor_Name']);
     $SN = mysqli_real_escape_string($connection, $_POST['Email']);
     $MS = mysqli_real_escape_string($connection, $_POST['Subject']);
     $MD = mysqli_real_escape_string($connection, $_POST['Detail']);
     $Date = mysqli_real_escape_string($connection, $_POST['Date']);
     $Time = mysqli_real_escape_string($connection, $_POST['Time']);

   $SQL = "INSERT INTO `meeting`(`MeetingID`, `TutorName`, `StudentName`, `MeetingSubject`, `MeetingDetail`, `Date`, `Time`, `userid`)
   VALUES  (NULL, '$TN', '$SN', '$MS', '$MD', '$Date', '$Time','$User')";
   mysqli_query($connection, $SQL);


   global $sendgrid;

   $email = new \SendGrid\Mail\Mail();
   $email->setFrom("hiroshenrao3@gmail.com", "Staff");
   $email->setSubject("Allocation");
   $email->addTo($_POST['Email']);
   $email->addTo($_POST['Tutor_Name']);
   $email->addContent("text/plain", "Dear Tutor, You have a meeting with your student.Please verify with your student. Thanks and Regards");

   $sendgrid = new\SendGrid('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');
   try {
       $response = $sendgrid->send($email);
       print $response->statusCode() . "\n";
       print_r($response->headers());
       print $response->body() . "\n";
   } catch (Exception $e) {
       echo 'Caught exception: '. $e->getMessage() ."\n";
   }
   header('location:meeting.php');
 }


 //Delete Meeting
 if (isset($_GET['Delete_Meeting'])) {
 	$MeetingID = $_GET['Delete_Meeting'];
 	mysqli_query($connection, "DELETE FROM meeting WHERE MeetingID=$MeetingID");
 	header('location:meeting.php');
 }

 //Call out the data from the database once user choose the specific data from table
 if (isset($_GET['Edit_Meeting'])) {
 		$MeetingID = $_GET['Edit_Meeting'];
 		$edit = true;
 		$meetingrecords = mysqli_query($connection, "SELECT * FROM meeting WHERE MeetingID=$MeetingID");
 		$meetingrecs= mysqli_fetch_array($meetingrecords);
 		$TN = $meetingrecs['TutorName'];
 		$SN = $meetingrecs['StudentName'];
     $MS = $meetingrecs['MeetingSubject'];
     $MD = $meetingrecs['MeetingDetail'];
     $Date = $meetingrecs['Date'];
     $Time = $meetingrecs['Time'];
 }


 if (isset($_POST['Update_Meeting'])) {

 //Variable to declare from the input name
 $MeetingID= $_POST['meetingidtable'];
 $TN = mysqli_real_escape_string($connection, $_POST['Tutor_Name']);
 $SN = mysqli_real_escape_string($connection, $_POST['Email']);
 $MS = mysqli_real_escape_string($connection, $_POST['Subject']);
 $MD = mysqli_real_escape_string($connection, $_POST['Detail']);
 $Date = mysqli_real_escape_string($connection, $_POST['Date']);
 $Time = mysqli_real_escape_string($connection, $_POST['Time']);

 mysqli_query($connection, "UPDATE meeting SET TutorName='$TN', StudentName='$SN', MeetingSubject='$MS', MeetingDetail='$MD', Date ='$Date', Time='$Time' WHERE MeetingID=$MeetingID");


 global $sendgrid;

 $email = new \SendGrid\Mail\Mail();
 $email->setFrom("hiroshenrao3@gmail.com", "Staff");
 $email->setSubject("Allocation");
 $email->addTo($_POST['Email']);
 $email->addTo($_POST['Tutor_Name']);
 $email->addContent("text/plain", "Dear Tutor, Your Date and Time has been changed to $Date, $Time. Thanks and Regards");

 $sendgrid = new\SendGrid('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');
 try {
     $response = $sendgrid->send($email);
     print $response->statusCode() . "\n";
     print_r($response->headers());
     print $response->body() . "\n";
 } catch (Exception $e) {
     echo 'Caught exception: '. $e->getMessage() ."\n";
 }
 header('location:meeting.php');
 }

  ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Student-Meeting</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.11.3/themes/smoothness/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-2.2.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  <script type="text/javascript">
    $(document).ready(function(){
      var minDate = new Date();
      $("#date").datepicker({
        showAnim: 'drop',
        numberofMonth: 1,
        minDate: minDate,
        dateFormat:'dd/mm/yy',
      });
    });
  </script>
</head>
<body>
  <?php
  $User = 	$_SESSION['uniqueuser'];
  $users = "SELECT * FROM login WHERE ID = '$User'";
  $results = mysqli_query($connection, $users);
  while($rows = mysqli_fetch_assoc($results)){;
  ?>
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <!-- Brand -->
    <a class="navbar-brand" href="#"><?php echo $rows['Username']; ?></a>

    <!-- Links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="TutorProfile.php">Tutor Profile</a>
      </li>
     <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="Upload.php">Upload File</a>
      </li>

      <ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="blog.php">My Blog</a>
       </li>
      </ul>

      <ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="meeting.php">Make Appointment</a>
       </li>

       <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="ViewStudent.php">View Student</a>
        </li>
        <ul class="navbar-nav">
 	      <li class="nav-item">
 	        <a class="nav-link" href="TutorChat.php">Chat</a>
 	      </li>

      <ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="/Enterprise/UserLogin.php?Logout='1'">LOGOUT</a>
       </li>
  </nav>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=email], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=time], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;

}
</style>
</head>
<body>

<br><h3>Make Meeting</h3>

<div class="container">
  <form  action="meeting.php" method="POST">
    <input type="hidden" name="meetingidtable" value="<?php echo $MeetingID; ?>">

    <input type="hidden" name="Email" value="<?php echo $rows['Email']; ?>">

    <input id="SN" type="text" name="Student_Name" value="<?php echo $rows['Username']; ?>" required>

    <input id="TN" type="email" name="Tutor_Name" placeholder="Student Name" value="<?php echo $TN; ?>"  required>

    <input id="MS" type="text" name="Subject" placeholder="Subject Name" value="<?php echo $MS; ?>"  required>

    <select class="" name="Detail" required>
      <option value="Virtual">Virtual</option>
      <option value="Reality">Reality</option>
    </select>

    <input id="MD" type="text" name="Detail" placeholder="Meeting Name" value="<?php echo $MD; ?>" required>

    <input id="date" type="text" name="Date" placeholder="Meeting Date" value="<?php echo $Date; ?>"  required>

    <input id="time" type="time" name="Time" placeholder="Meeting Time"value="<?php echo $Time; ?>"  required>

    <?php if ($edit == false):?>
        <button type="submit" name="Book_Meeting" class="btn btn-primary" style="width:80px;">Post</button>
    <?php else: ?>
        <button type="submit" name="Update_Meeting" class="btn btn-success" style="width:200px;">Update Changes</button>
    <?php endif ?>
  </form>

	<br>
	<br>
	<br>
			<table class="table table-striped table-dark">
      <thead>
        <tr>
      	<th>StudentName</th>
        <th>MeetingSubject</th>
        <th>MeetingDetail</th>
        <th>Date</th>
        <th>Time</th>
        <th colspan="2"><center>Action</center></th>
        </tr>
          </thead>
              <tbody>
                  <?php
                  $sql = "SELECT * FROM meeting WHERE userid='$User'";
                  $results = mysqli_query($connection, $sql);
                	while($rows = mysqli_fetch_assoc($results)){;
                  ?>

                  <tr>
                    <td class="bg-primary"><?php echo $rows['TutorName']; ?></td>
                    <td class="bg-info"><?php echo $rows['MeetingSubject']; ?></td>
                    <td class="bg-info"><?php echo $rows['MeetingDetail']; ?></td>
                    <td class="bg-info"><?php echo $rows['Date']; ?></td>
                    <td class="bg-info"><?php echo $rows['Time']; ?></td>
                    <td class="text-right">
                        <a href="meeting.php?Edit_Meeting=<?php echo $rows['MeetingID']; ?>" class="btn btn-warning" style="width:80px;" >Edit</a>
                    </td>
                    <td>
                        <a href="meeting.php?Delete_Meeting=<?php echo $rows['MeetingID']; ?>" class="btn btn-danger" style="width:80px;">Delete</a>
                    </td>
                    </tr>
                    <?php } ?>
                </tbody>
								</table>
								</div>
<?php } ?>
</body>
</html>
