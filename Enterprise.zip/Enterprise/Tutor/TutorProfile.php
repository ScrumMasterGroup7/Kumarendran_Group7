<?php


$connection = mysqli_connect('localhost', 'root', '', 'enterprise');
session_start();
if(empty($_SESSION['Email'])) {
  header('location:/Enterprise/UserLogin.php');
}
elseif ($_SESSION['type']!=='Tutor') {
  echo "<script>window.open('/Enterprise/UserLogin.php', '_self')</script>";
}

 ?>

<!DOCTYPE html>
<html>
<body bgcolor="#e6faf8">
<head>
  <title>TutorProfile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=submit] {
  background-color: #eb7610;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

</style>
</head>
<body>
  <?php
  $User = 	$_SESSION['uniqueuser'];
  $users = "SELECT * FROM login WHERE ID = '$User'";
  $results = mysqli_query($connection, $users);
  while($rows = mysqli_fetch_assoc($results)){;
  ?>
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <!-- Brand -->
    <a class="navbar-brand" href="Tutor.php"><?php echo $rows['Username']; ?></a>

    <!-- Links -->
    <ul class="navbar-nav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="TutorProfile.php">Tutor Profile</a>
        </li>
       <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="Upload.php">Upload File</a>
        </li>

        <ul class="navbar-nav">
         <li class="nav-item">
           <a class="nav-link" href="blog.php">My Blog</a>
         </li>
        </ul>

        <ul class="navbar-nav">
         <li class="nav-item">
           <a class="nav-link" href="meeting.php">Make Appointment</a>
         </li>

         <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="ViewStudent.php">View Student</a>
          </li>
          <ul class="navbar-nav">
           <li class="nav-item">
             <a class="nav-link" href="TutorChat.php">Chat</a>
           </li>
        <ul class="navbar-nav">
         <li class="nav-item">
           <a class="nav-link" href="/Enterprise/UserLogin.php?Logout='1'">LOGOUT</a>
         </li>
  </nav>
<br><h2>TutoProfile</h2>
<br>
<h2><?php echo $rows['Username']; ?></h2>
<h4><?php echo $rows['Email']; ?></h4>
<h4><?php echo $rows['Category']; ?></h4>
</div>
<?php } ?>
</body>
</html>
