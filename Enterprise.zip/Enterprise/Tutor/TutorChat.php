<?php
	session_start();
$connection = mysqli_connect('localhost', 'root', '', 'enterprise');
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";
$tutor = $_SESSION["Username"];
//echo $tutor;
date_default_timezone_set('Asia/Kuala_Lumpur');
$time = date('H:i:s');
$date = date('d-m-Y');
//echo "Date is ".$date."Time is ".$time;
$Date = "Date is ".$date."Time is ".$time;

if (isset($_POST['Send'])) {
	$S = $_SESSION["uniqueuser"];

	$students = mysqli_real_escape_string($connection, $_POST['student']);
	$tutor = $_SESSION["Username"];
  echo $tutor;
  $Tutor = $tutor;
	$contents = mysqli_real_escape_string($connection,$_POST["chatText"]);

	$sql1 = "INSERT INTO chat(send,receive,contents,times) VALUES('$Tutor','$students','$contents','$Date')";
	if ($result1 = mysqli_query($connection, $sql1)) {
		$INFO = "Send Successfully";
		echo "<script type='text/javascript'>alert('$INFO');</script>";
		echo "<script type='text/javascript'>window.location = 'TutorChat.php';</script>";
	}
  else {
    echo "<script type='text/javascript'>alert('Fail');</script>";
  }
}
$S =  $_SESSION["uniqueuser"];
$tutor = $_SESSION["Username"];
$Tutor = $tutor;
$sql2 = "SELECT * FROM chat WHERE send='$Tutor' OR receive='$Tutor' ORDER BY times DESC";
mysqli_query($connection, $sql2) or die(mysqli_error($connection));
$result2 = mysqli_query($connection, $sql2);
//$search = $_POST['name'];

//$sql3 = "SELECT * FROM chat WHERE send LIKE '%" . $search .  "%' OR receive LIKE '%" . $search ."%'";
//mysqli_query($connection, $sql2) or die(mysqli_error($connection));
//$result3 = mysqli_query($connection, $sql3);
//$sql="SELECT * FROM tutor WHERE tutor_name=$tutor AND student='$n'";
?>

<html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">-->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="Tables.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<style media="screen">
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

html {
	background-color: #56baed;
}


input[type=text], select, textarea {
	width: 100%;
	padding: 12px;
	border: 1px solid #ccc;
	border-radius: 4px;
	box-sizing: border-box;
	margin-top: 6px;
	margin-bottom: 16px;
	resize: vertical;
}
input[type=submit] {
	background-color: #eb7610;
	color: white;
	padding: 12px 20px;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}

.w3-myfont {
  font-family: "Comic Sans MS", cursive, sans-serif;
}

.Box{
  background-color: lightgrey;
	width: 700px;
  border: 15px solid green;
  padding: 70px;
  margin: 50px;
}

h1{
  font-size: 30px;
  color: #fff;
  text-transform: uppercase;
  font-weight: 300;
  text-align: center;
  margin-bottom: 15px;
}



/* demo styles */

@import url(https://fonts.googleapis.com/css?family=Roboto:400,500,300,700);
body{

  font-family: 'Roboto', sans-serif;
}
section{
  margin: 50px;
}


/* follow me template */
.made-with-love {
  margin-top: 40px;
  padding: 10px;
  clear: left;
  text-align: center;
  font-size: 10px;
  font-family: arial;
  color: #fff;
}
.made-with-love i {
  font-style: normal;
  color: #F50057;
  font-size: 14px;
  position: relative;
  top: 2px;
}
.made-with-love a {
  color: #fff;
  text-decoration: none;
}
.made-with-love a:hover {
  text-decoration: underline;
}



/* follow me template */
.made-with-love {
  margin-top: 40px;
  padding: 10px;
  clear: left;
  text-align: center;
  font-size: 10px;
  font-family: arial;
  color: #fff;
}
.made-with-love i {
  font-style: normal;
  color: #F50057;
  font-size: 14px;
  position: relative;
  top: 2px;
}
.made-with-love a {
  color: #fff;
  text-decoration: none;
}
.made-with-love a:hover {
  text-decoration: underline;
}


</style>
<body>
	<?php
	$User = 	$_SESSION['uniqueuser'];
	$users = "SELECT * FROM login WHERE ID = '$User'";
	$results = mysqli_query($connection, $users);
	while($rows = mysqli_fetch_assoc($results)){;
	?>
	<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
	  <!-- Brand -->
	  <a class="navbar-brand" href="Tutor.php"><?php echo $rows['Username']; ?></a>

	  <!-- Links -->
	  <ul class="navbar-nav">
			<ul class="navbar-nav">
	      <li class="nav-item">
	        <a class="nav-link" href="TutorProfile.php">Tutor Profile</a>
	      </li>
	     <ul class="navbar-nav">
	      <li class="nav-item">
	        <a class="nav-link" href="Upload.php">Upload File</a>
	      </li>

	      <ul class="navbar-nav">
	       <li class="nav-item">
	         <a class="nav-link" href="blog.php">My Blog</a>
	       </li>
	      </ul>

	      <ul class="navbar-nav">
	       <li class="nav-item">
	         <a class="nav-link" href="meeting.php">Make Appointment</a>
	       </li>

	       <ul class="navbar-nav">
	        <li class="nav-item">
	          <a class="nav-link" href="ViewStudent.php">View Student</a>
	        </li>
	        <ul class="navbar-nav">
	         <li class="nav-item">
	           <a class="nav-link" href="TutorChat.php">Chat</a>
	         </li>
	      <ul class="navbar-nav">
	       <li class="nav-item">
	         <a class="nav-link" href="/Enterprise/UserLogin.php?Logout='1'">LOGOUT</a>
	       </li>
	</nav>

	<h1 class="w3-myfont" align="middle">CHAT MESSAGE</h1>

	<div class="Box">
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">


			<?php
			$S =   $_SESSION["uniqueuser"];
			$T = $_SESSION['Username'];
			$sql = "SELECT * FROM allocate WHERE TutorName='$T'";
			$result = mysqli_query($connection, $sql);

			echo "<select name='student' style='margin-top:50px;'required>";
			echo "<option value='' selected disabled>Select Student Email</option>";

			if (mysqli_num_rows($result) > 0) {
				echo "<label for='text'>student:</label>";

				while ($row = mysqli_fetch_array($result)) {

            $student = $row['StudentName'];


					echo "<option value=$student>$student</option>";
				}
			} else {
				echo "No User !";
			}
			echo "</select>";

			?><br>
			<br><textarea class="message-input" name="chatText" placeholder="Chat Start" required></textarea><br>
			<br><button type="submit" name="Send">Send</button>
		</div>

		<hr>

		<div class="table-wrapper">
		<!--	<form  method="post" action="TutorChat.php"  id="searchform">
	      <input  type="text" name="name">
	      <input  type="submit" name="submit" value="Search">
	    </form> -->
	<table class="fl-table">
				<thead>
					<tr>
						<th style="text-align:center;">Sender</th>
						<th style="text-align:center;">Reciever</th>
						<th style="text-align:center;">Content</th>
						<th style="text-align:center;">Time</th>
					</tr>
				</thead>

				<tbody>
					<?php
					while ($row = mysqli_fetch_assoc($result2)) {
					?>

						<tr>
							<td><?php echo $row['send'] ?></td>
							<td><?php echo $row['receive'] ?></td>
							<td><?php echo $row['contents'] ?></td>
							<td><?php echo $row['times'] ?></td>
						</tr>
					<?php
				}
					?>
				</tbody>
			</table>

		</div>
	</form>
<?php } ?>
</body>

</html>
<script>
	$(document).ready(function() {
		$('#dataTable').DataTable({
			"lengthMenu": [
				[3, 5, 10, -1],
				[3, 5, 10, "All"]
			]

		});
	});
</script>
