<?php
$connection = mysqli_connect('localhost', 'root', '', 'enterprise');
session_start();
$user = $_SESSION['uniqueuser'];
if (!$_SESSION['Email']) {
  echo "<script>window.open('UserLogin.php', '_self')</script>";
}
elseif ($_SESSION['type']!=='Admin') {
  echo "<script>window.open('UserLogin.php', '_self')</script>";
}
 ?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </head>
  <body>
    <?php
    $User = 	$_SESSION['uniqueuser'];
    $users = "SELECT * FROM login WHERE ID = '$User'";
    $results = mysqli_query($connection, $users);
    while($rows = mysqli_fetch_assoc($results)){;
    ?>
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
      <!-- Brand -->
      <a class="navbar-brand" href="#"><?php echo $rows['Username']; ?></a>

      <!-- Links -->
      <ul class="navbar-nav">

        <ul class="navbar-nav">

          <li class="nav-item">
            <a class="nav-link" href="staffprofile.php">Staff Profile</a>
          </li>
         <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="Allocate.php">Allocate</a>
          </li>
      <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="Reallocate.php">Re-allocate</a>
          </li>

          <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="ViewStudent.php">View Student</a>
              </li>

              <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link" href="ViewTutor.php">View Tutor</a>
                  </li>

           <ul class="navbar-nav" align="right">
            <li class="nav-item">
              <a class="nav-link" href="/Enterprise/UserLogin.php?Logout='1'">Logout</a>
            </li>

      </nav>
    <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Student Name</th>
	  <th scope="col">Student Email</th>
	  <th scope="col">Tutor Name</th>
	  <th scope="col">Tutor Email</th>
	  <th scope="col">Action</th>
    </tr>
  </thead>
<?php
$user = $_SESSION['uniqueuser'];
$conn = mysqli_connect('localhost', 'root', '', 'enterprise');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM allocate";
$result = mysqli_query($conn,$sql);

if ($result-> num_rows > 0) {
	$i = 1;
	while ($row = $result-> fetch_assoc()) {
		echo "<tr><td>". $i ."</td><td>". $row["StudentName"]. "</td><td>". $row["StudentEmail"]. "</td><td>". $row["TutorName"]. "</td><td>". $row["TutorEmail"]. "</td><td><a href=studentreallocate.php?AllocateID=". $row["AllocateID"]. ">Reallocate</a></td></tr>";
		$i++;
	}
	echo "</table>";
}else {
	echo "0 result";
}

$conn-> close();
?>
  <?php } ?>
	</body>
</html>
