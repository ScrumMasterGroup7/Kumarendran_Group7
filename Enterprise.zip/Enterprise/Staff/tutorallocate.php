<?php
session_start();
$User = $_SESSION['uniqueuser'];
$conn = mysqli_connect('localhost', 'root', '', 'enterprise');
require './vendor/autoload.php';


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!$_SESSION['Email']) {
  echo "<script>window.open('UserLogin.php', '_self')</script>";
}
elseif ($_SESSION['type']!=='Admin') {
  echo "<script>window.open('UserLogin.php', '_self')</script>";
}

$userID=$_REQUEST['userID'];
$sql= "SELECT * from tutor where userID='".$userID."'";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
$sqlSet = "SELECT studentName FROM student WHERE PersonalTutorName = ''";
$resultSet = mysqli_query($conn,$sqlSet);

if (isset($_POST['Allocate'])) {
$userID=$_REQUEST['userID'];
$StudentName = $_POST['StudentName'];
$StudentEmail = $_POST['StudentEmail'];
$TutorName = $_POST['TutorName'];
$TutorEmail = $_POST['TutorEmail'];

$sql1 = "UPDATE student SET PersonalTutorName = '$TutorName' WHERE StudentName = '$StudentName'";
$result1 = mysqli_query($conn, $sql1);
$sql2 = "INSERT INTO allocate(AllocateID, StudentName, StudentEmail, TutorName, TutorEmail)
                      VALUES (NULL, '$StudentName', '$StudentEmail', '$TutorName', '$TutorEmail')";
$result2 = mysqli_query($conn, $sql2);
		global $sendgrid;

					$email = new \SendGrid\Mail\Mail();
					$email->setFrom("hiroshenrao3@gmail.com", "Staff");
					$email->setSubject("Allocation");
					$email->addTo($_POST['StudentEmail']);
          $email->addTo($_POST['TutorEmail']);
					$email->addContent("text/plain", "Your tutor will be $TutorName and Student will be $StudentName");

          $sendgrid = new\SendGrid('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');
          try {
              $response = $sendgrid->send($email);
              print $response->statusCode() . "\n";
              print_r($response->headers());
              print $response->body() . "\n";
          } catch (Exception $e) {
              echo 'Caught exception: '. $e->getMessage() ."\n";
          }
          echo "Post Have Been Saved";
          header('location:Allocate.php');
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

  </head>
  <body onload="myFunction()">
    <style media="screen">
        .form-container div, .form-container  span{
      font-family: Calibri, Candara, Segoe, 'Segoe UI', Optima, Arial, sans-serif;
    }

    .form-container .req-input .input-status {
      display: inline-block;
      height: 40px;
      width: 40px;
      float: left;
    }

    .form-container .input-status::before{
    content: " ";
    height:20px;
    width:20px;
    position:absolute;
    top:10px;
    left:10px;
    color:white;
    border-radius:50%;
    background:white;
    -webkit-transition: all .3s ease-in-out;
    -moz-transition: all .3s ease-in-out;
    -o-transition: all .3s ease-in-out;
    transition: all .3s ease-in-out;

    }

    .form-container .input-status::after{
    content: " ";
    height:10px;
    width:10px;
    position:absolute;
    top:15px;
    left:15px;
    color:white;
    border-radius:50%;
    background:#00BCD4;
    -webkit-transition: all .3s ease-in-out;
    -moz-transition: all .3s ease-in-out;
    -o-transition: all .3s ease-in-out;
    transition: all .3s ease-in-out;
    }

    .form-container .req-input{
    width:100%;
      float:left;
    position:relative;
    background:#00BCD4;
    height:40px;
    display:inline-block;
    border-radius:0px;
    margin:5px 0px;
    -webkit-transition: all .3s ease-in-out;
    -moz-transition: all .3s ease-in-out;
    -o-transition: all .3s ease-in-out;
    transition: all .3s ease-in-out;
    }

    .form-container div .row .invalid:hover{
    background:#EF9A9A;
    }

    .form-container div .row .invalid{
    background:#E57373;
    }

    .form-container .invalid .input-status:before {
    width:20px;
    height:4px;
    top:19px;
    left:10px;
    background:white;/*#F44336;*/
    border-radius:0px;
    -ms-transform: rotate(45deg); /* IE 9 */
    -webkit-transform: rotate(45deg); /* Chrome, Safari, Opera */
    transform: rotate(45deg);
    }

    .form-container .invalid .input-status:after {
    width:20px;
    height:4px;
    background:white;
    border-radius:0px;
    top:19px;
    left:10px;
    -ms-transform: rotate(-45deg); /* IE 9 */
    -webkit-transform: rotate(-45deg); /* Chrome, Safari, Opera */
    transform: rotate(-45deg);
    }

    .form-container div .row  .valid:hover{
    background:#A5D6A7;
    }

    .form-container div .row .valid {
    background:#81C784;

    }

    .form-container .valid .input-status:after {
      border-radius:0px;
      width: 17px;
      height: 4px;
      background: white;
      top: 16px;
      left: 15px;
      -ms-transform: rotate(-45deg);
      -webkit-transform: rotate(-45deg);
      transform: rotate(-45deg);
    }

    .form-container .valid .input-status:before {
      border-radius:0px;
      width: 11px;
      height: 4px;
      background:white;
      top: 19px;
      left: 10px;
      -ms-transform: rotate(45deg);
      -webkit-transform: rotate(45deg);
      transform: rotate(45deg);
    }

    .form-container .input-container{
    padding:0px 20px;
    }

    .form-container .row-input{
    padding:0px 5px;
    }

    .form-container {
    margin:20px;
    padding:20px;
    border-radius:0px;
    background:#B3E5FC;
    color:#00838F;
    -webkit-transition: all .3s ease-in-out;
    -moz-transition: all .3s ease-in-out;
    -o-transition: all .3s ease-in-out;
    transition: all .3s ease-in-out;
    }

    .form-container .form-title{
    font-size:25px;
    color:inherit;
    text-align:center;
    margin-bottom:10px;
    -webkit-transition: all .3s ease-in-out;
    -moz-transition: all .3s ease-in-out;
    -o-transition: all .3s ease-in-out;
    transition: all .3s ease-in-out;
    }

    .form-container .submit-row{
    padding:0px 0px;
    }

    .form-container .btn.submit-form{
    margin-top:15px;
    padding:12px;
    background:#00BCD4;
    color:white;
    border-radius:0px;
    -webkit-transition: all .3s ease-in-out;
    -moz-transition: all .3s ease-in-out;
    -o-transition: all .3s ease-in-out;
    transition: all .3s ease-in-out;
    }

    .form-container .message-box{
    width:100%;
    height:auto;
    }

    .form-container textarea:focus,.form-container textarea:hover{
    background:#fff;
    outline:none;
    border:0px;
    }

    .form-container .req-input textarea {
    max-width:calc(100% - 50px);
      width: 100%;
      height: 80px;
      border: 0px;
      color: #777;
      padding: 10px 9px 0px 9px;
    float:left;

    }
    .form-container input[type=text]:focus,  .form-container select:focus
    {
      background:#fff;
    color:#777;
    border-left:0px;
    outline:none;
    }

    .form-container input[type=text]:hover,.form-container select:hover,
    {
    background:#fff;
    }

    .form-container input[type=text],  .form-container select{
    width:calc(100% - 50px);
    float:left;
    border-radius:0px;
    border:0px solid #ddd;
    padding:0px 9px;
    height:40px;
    line-height:40px;
    color:#777;
    background:#fff;
    -webkit-transition: all .3s ease-in-out;
    -moz-transition: all .3s ease-in-out;
    -o-transition: all .3s ease-in-out;
    transition: all .3s ease-in-out;
    }
    </style>
    <body>
      <?php
      $User = 	$_SESSION['uniqueuser'];
      $users = "SELECT * FROM login WHERE ID = '$User'";
      $results = mysqli_query($conn, $users);
      while($rows = mysqli_fetch_assoc($results)){;
      ?>
      <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
        <!-- Brand -->
        <a class="navbar-brand" href="#"><?php echo $rows['Username']; ?></a>

        <!-- Links -->
        <ul class="navbar-nav">

          <ul class="navbar-nav">

            <li class="nav-item">
              <a class="nav-link" href="staffprofile.php">Staff Profile</a>
            </li>
           <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="Allocate.php">Allocate</a>
            </li>
        <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="Reallocate.php">Re-allocate</a>
            </li>

            <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" href="ViewStudent.php">View Student</a>
                </li>

                <ul class="navbar-nav">
                    <li class="nav-item">
                      <a class="nav-link" href="ViewTutor.php">View Tutor</a>
                    </li>

             <ul class="navbar-nav" align="right">
              <li class="nav-item">
                <a class="nav-link" href="/Enterprise/UserLogin.php?Logout='1'">Logout</a>
              </li>

        </nav>
<center>
        <div class="col-md-4">

    		<form class="" onload="myFunction2()" action="tutorallocate.php" method="post">

			<div id="contact-form" class="form-container" data-form-container style="color: rgb(46, 125, 50); background: rgb(200, 230, 201);">
			<div class="row">
				<div class="form-title">
					<span> Allocate Student </span>
				</div>
			</div>
				<input name="userID" type="hidden" value="<?php echo $row['userID'];?>" />

			<div class="input-container">
				<div class="row">
					<span class="req-input valid" >
						<span class="input-status" data-toggle="tooltip" data-placement="top" title="Tutor Name" > </span>
						<input type="text" data-min-length="8" value="<?php echo $row['tutorName'];?>" name="TutorName" readonly>
					</span>
				</div>

				<input name="TutorEmail" type="hidden" value="<?php echo $row['tutorEmail'];?>" />

				<div class="row">
					<span class="req-input message-box valid">
						<span class="input-status" data-toggle="tooltip" data-placement="top" title="Student Name"> </span>
						<select id="StudentNameSelect" name = "StudentName" onchange="myFunction()" required>
						<?php
						while($rows = $resultSet->fetch_assoc()){
							$sName = $rows['studentName'];
							echo "<option value = '$sName'>$sName</option>";
						}
						?>
						</select>
				</div>

				<div class="row">
					<span class="req-input message-box valid">
						<span class="input-status" data-toggle="tooltip" data-placement="top" title="Tutor Email"> </span>
						<input type="text" id="StudentEmailSelect" data-min-length="8"  name="StudentEmail" readonly>
				</div>

				<div class="row submit-row">
          <button type="submit" class="btn btn-block submit-form valid" name="Allocate">Allocate</button>

				</div>
			</div>
			</div>
			</form>
		</div>
	<script>
		function myFunction() {
			var x = document.getElementById("StudentNameSelect").value;
			document.getElementById("StudentEmailSelect").value = x.toLowerCase() + "@gmail.com";
		}
	</script>
</center>
<?php } ?>
  </body>
</html>
