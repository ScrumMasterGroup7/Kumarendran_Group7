<?php


$connection = mysqli_connect('localhost', 'root', '', 'enterprise');
session_start();
$user = $_SESSION['uniqueuser'];
if (!$_SESSION['Email']) {
  echo "<script>window.open('UserLogin.php', '_self')</script>";
}
elseif ($_SESSION['type']!=='Admin') {
  echo "<script>window.open('UserLogin.php', '_self')</script>";
}

 ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Student</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
  <?php
  $User = 	$_SESSION['uniqueuser'];
  $users = "SELECT * FROM login WHERE ID = '$User'";
  $results = mysqli_query($connection, $users);
  while($rows = mysqli_fetch_assoc($results)){;
  ?>
  <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <!-- Brand -->
    <a class="navbar-brand" href="#"><?php echo $rows['Username']; ?></a>

    <!-- Links -->
    <ul class="navbar-nav">

      <ul class="navbar-nav">

        <li class="nav-item">
          <a class="nav-link" href="staffprofile.php">Staff Profile</a>
        </li>
       <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="Allocate.php">Allocate</a>
        </li>
    <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="Reallocate.php">Re-allocate</a>
        </li>

        <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="ViewStudent.php">View Student</a>
            </li>

            <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" href="ViewTutor.php">View Tutor</a>
                </li>

         <ul class="navbar-nav" align="right">
          <li class="nav-item">
            <a class="nav-link" href="/Enterprise/UserLogin.php?Logout='1'">Logout</a>
          </li>

    </nav>
<br><h2>Staff Profile</h2>
<p></p>
<h2><?php echo $rows['Username']; ?></h2>
<p><?php echo $rows['Category']; ?></p>
<p><b></b></p>
<p></p>
<?php } ?>
</body>
</html>
