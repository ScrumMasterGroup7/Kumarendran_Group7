<?php

$connection = mysqli_connect('localhost', 'root', '', 'enterprise');
session_start();
if (!$_SESSION['Email']) {
  echo "<script>window.open('/Enterprise/UserLogin.php', '_self')</script>";
}
elseif ($_SESSION['type']!=='Student') {
  echo "<script>window.open('/Enterprise/UserLogin.php', '_self')</script>";
}

$User = 	$_SESSION['uniqueuser'];
$sql ="SELECT blogid, count(*) as number FROM blog WHERE userid='$User'";
$resultblog = mysqli_query($connection,$sql);


$sql ="SELECT MeetingID, count(*) as number FROM meeting WHERE userid='$User'";
$resultmeeting = mysqli_query($connection,$sql);

?>


 <!DOCTYPE html>
 <html lang="en">

 <head>
   <title>Student</title>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
   <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
   <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <script type="text/javascript">
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

          var data = google.visualization.arrayToDataTable([
            ['userid', 'Number'],
            <?php

            while ($rows = mysqli_fetch_array($resultblog)) {
              echo "['".$rows["blogid"]."',".$rows["number"]."],";
            }

            ?>
          ]);

          var options = {title:'Total Blog',
          width: 600,
          height: 400};

          var chart = new google.visualization.PieChart(document.getElementById('piechart_blog'));

          chart.draw(data, options);
        }
    </script>


    <script type="text/javascript">
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

          var data = google.visualization.arrayToDataTable([
            ['StudentName', 'Number'],
            <?php

            while ($rows = mysqli_fetch_array($resultmeeting)) {
              echo "['".$rows["MeetingID"]."',".$rows["number"]."],";
            }

            ?>
          ]);

          var options = {
            title: "Meeting",
            width: 600,
            height: 400,
            bar: {groupWidth: "95%"},
            legend: { position: "none" },
          };

          var chart = new google.visualization.BarChart(document.getElementById('barchart_meeting'));

          chart.draw(data, options);
        }
    </script>
 </head>
 <body>
   <?php
   $User = 	$_SESSION['uniqueuser'];
   $users = "SELECT * FROM login WHERE ID = '$User'";
   $results = mysqli_query($connection, $users);
   while($rows = mysqli_fetch_assoc($results)){;
   ?>
   <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
     <!-- Brand -->
     <a class="navbar-brand" href="#"><?php echo $rows['Username']; ?></a>

     <!-- Links -->
   	<ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="studentprofile.php">Student Profile</a>
       </li>
   		</ul>
      <ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="Upload.php">Upload File</a>
       </li>
   		</ul>

      <ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="meeting.php">Make Appointment</a>
       </li>
   		</ul>

   		<ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="blog.php">My Blog</a>
        </li>
   		</ul>

   		<ul class="navbar-nav">
   		 <li class="nav-item">
   			 <a class="nav-link" href="studentdashboard.php">Student Dashboard</a>
   		 </li>
        <ul class="navbar-nav">
         <li class="nav-item">
           <a class="nav-link" href="StudentChat.php">Chat</a>
         </li>

        <ul class="navbar-nav">
         <li class="nav-item">
           <a class="nav-link" href="/Enterprise/UserLogin.php?Logout='1'">LOGOUT</a>
         </li>
   </nav>
 <br><h2>Student Dashboard</h2>

       <div class="PieChartalign">

         <table class="columns">
           <tr>
             <td><div id="piechart_blog"style="border: 2px solid #00FA9A" style="width:900px; height:550px;"></div></td>
             <td><div id="barchart_meeting" style="border: 2px solid #00FA9A" style="width:900px; height:550px;"></div></td>
           </tr>
         </table>

         <br>
         <br>
     </div>
   </div>

<?php } ?>
</body>
</html>
