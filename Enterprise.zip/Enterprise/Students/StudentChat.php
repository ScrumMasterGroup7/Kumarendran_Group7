<?php
session_start();
$connection = mysqli_connect('localhost', 'root', '', 'enterprise');
if ($connection->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

if (!$_SESSION['Email']) {
  echo "<script>window.open('/Enterprise/UserLogin.php', '_self')</script>";
}
elseif ($_SESSION['type']!=='Student') {
  echo "<script>window.open('/Enterprise/UserLogin.php', '_self')</script>";
}


if (isset($_POST['Send'])) {
	$User = $_SESSION['uniqueuser'];
	$Name = $_SESSION['Username'];
	$Names = $Name;
	$student = $_POST['student'];
	$tutor = $User;
	$content = $_POST["Chat"];
	date_default_timezone_set("Asia/Kuala_Lumpur");
	$timestamp = date('Y-m-d G:i:s');

	$sql1 = "INSERT INTO chat(send,receive,contents,times) VALUES('$Names','$student','$content','$timestamp')";
	if ($result1 = mysqli_query($connection, $sql1)) {
		$INFO = "Send Successfully";
		echo "<script type='text/javascript'>alert('$INFO');</script>";
		echo "<script type='text/javascript'>window.location = 'StudentChat.php';</script>";
	}
	else {
		echo "<script type='text/javascript'>alert('Fail');</script>";
	}
}

$S =  $_SESSION['uniqueuser'];
$User = $_SESSION['Username'];
$Users = $User;
$sql2 = "SELECT * FROM chat WHERE send ='$Users' OR receive='$Users' ORDER BY times DESC";
mysqli_query($connection, $sql2) or die(mysqli_error($connection));
$result2 = mysqli_query($connection, $sql2);



//$sql="SELECT * FROM tutor WHERE tutor_name=$tutor AND student='$n'";
?>

<html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">-->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="Tables.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<style media="screen">
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

html {

}


input[type=text], select, textarea {
	width: 100%;
	padding: 12px;
	border: 1px solid #ccc;
	border-radius: 4px;
	box-sizing: border-box;
	margin-top: 6px;
	margin-bottom: 16px;
	resize: vertical;
}
input[type=submit] {
	background-color: #eb7610;
	color: white;
	padding: 12px 20px;
	border: none;
	border-radius: 4px;
	cursor: pointer;
}

.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}

.w3-myfont {
  font-family: "Comic Sans MS", cursive, sans-serif;
}

.Box{
  background-color: lightgrey;
	width: 700px;
  border: 15px solid green;
  padding: 70px;
  margin: 50px;
}

h1{
  font-size: 30px;
  color: #fff;
  text-transform: uppercase;
  font-weight: 300;
  text-align: center;
  margin-bottom: 15px;
}
table{
  width:100%;
  table-layout: fixed;
}
.tbl-header{
  background-color: rgba(255,255,255,0.3);
 }
.tbl-content{
  height:300px;
  overflow-x:auto;
  margin-top: 0px;
  border: 1px solid rgba(255,255,255,0.3);
}
th{
  padding: 20px 15px;
  text-align: left;
  font-weight: 500;
  font-size: 12px;
  color: #fff;
  text-transform: uppercase;
}
td{
  padding: 15px;
  text-align: left;
  vertical-align:middle;
  font-weight: 300;
  font-size: 12px;
  color: black;
  border-bottom: solid 1px rgba(255,255,255,0.1);
}


/* demo styles */

@import url(https://fonts.googleapis.com/css?family=Roboto:400,500,300,700);
body{
  background: -webkit-linear-gradient(left, #25c481, #25b7c4);
  background: linear-gradient(to right, #25c481, #25b7c4);
  font-family: 'Roboto', sans-serif;
}
section{
  margin: 50px;
}


/* follow me template */
.made-with-love {
  margin-top: 40px;
  padding: 10px;
  clear: left;
  text-align: center;
  font-size: 10px;
  font-family: arial;
  color: #fff;
}
.made-with-love i {
  font-style: normal;
  color: #F50057;
  font-size: 14px;
  position: relative;
  top: 2px;
}
.made-with-love a {
  color: #fff;
  text-decoration: none;
}
.made-with-love a:hover {
  text-decoration: underline;
}


</style>
<body>
	<?php
  $User = 	$_SESSION['uniqueuser'];
  $users = "SELECT * FROM login WHERE ID = '$User'";
  $results = mysqli_query($connection, $users);
  while($rows = mysqli_fetch_assoc($results)){;
  ?>
	<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <!-- Brand -->
    <a class="navbar-brand" href="#"><?php echo $rows['Username']; ?></a>

    <!-- Links -->
  	<ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="studentprofile.php">Student Profile</a>
      </li>
  		</ul>
     <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="Upload.php">Upload File</a>
      </li>
  		</ul>

			<ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="meeting.php">Make Appointment</a>
      </li>
  		</ul>

  		<ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="blog.php">My Blog</a>
       </li>
  		</ul>

  		<ul class="navbar-nav">
  		 <li class="nav-item">
  			 <a class="nav-link" href="studentdashboard.php">Student Dashboard</a>
  		 </li>
       <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="StudentChat.php">Chat</a>
        </li>

       <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="/Enterprise/UserLogin.php?Logout='1'">LOGOUT</a>
        </li>
  </nav>

		<h1 class="w3-myfont" align="middle">CHAT MESSAGE</h1>
<div class="Box">
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
			<?php
			$User = $_SESSION['uniqueuser'];
			$Username = $_SESSION['Username'];
			$sql = "SELECT * FROM allocate WHERE StudentName='$Username'";
			$result = mysqli_query($connection, $sql);

			echo "<select name='student' style='margin-top:50px;'required>";
			echo "<option value='' selected disabled>Select Tutor Email</option>";

			if (mysqli_num_rows($result) > 0) {
				echo "<label for='text'>student:</label>";

				while ($row = mysqli_fetch_array($result)) {
					$student = $row['TutorName'];

					echo "<option value=$student>$student</option>";
				}
			} else {
				echo "No User !";
			}
			echo "</select>";

			?><br>

			<br><textarea class="message-input" name="Chat" placeholder="Chat" required></textarea><br>
			<br><button type="submit" name="Send" class="button">Send</button>
			</div>

		<hr>
		<div class="table-wrapper">
	<table class="fl-table">
				<thead>
					<tr>
						<th style="text-align:center;">Sender</th>
						<th style="text-align:center;">Reciever</th>
						<th style="text-align:center;">Content</th>
						<th style="text-align:center;">Time</th>
					</tr>
				</thead>


				<tbody>
					<?php
					while ($row = mysqli_fetch_assoc($result2)) {
					?>
						<tr>
							<td><?php echo $row['receive']; ?></td>
							<td><?php echo $row['send']; ?></td>
							<td><?php echo $row['contents']; ?></td>
							<td><?php echo $row['times']; ?></td>
						</tr>
					<?php
			}

					?>
				</tbody>
			</table>
			</div>
			</table>
	</form>
<?php } ?>
</body>

</html>
<!--
<script>
	$(document).ready(function() {
		$('#dataTable').DataTable({
			"lengthMenu": [
				[3, 5, 10, -1],
				[3, 5, 10, "All"]
			]

		});
	});
</script>
-->
